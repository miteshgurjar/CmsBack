﻿//using CustomerManagmentSysytem.Data.Models;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;
//using System.Linq;
//using System.Threading.Tasks;

//namespace CustomerManagmentSysytem.Data.Mdoels
//{
//    public class Dependencies
//    {
//        //[Key]
//        //public int DependencyId { get; set; }
       
//        //[ForeignKey("Service")]
//        //public int ServiceId { get; set; }
//        //public ServiceTypes Service { get; set; }
//        //[ForeignKey("customers")]
//        //public int CustomerId { get; set; }

//        //public bool isWorking { get; set; }
//        //public Customers customers { get; set; }
//        //public List<Customer_Dependency> Customer_Dependency { get; set; }
//    }
//}
