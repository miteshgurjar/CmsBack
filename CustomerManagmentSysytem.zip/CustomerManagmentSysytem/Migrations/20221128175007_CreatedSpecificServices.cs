﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagmentSysytem.Migrations
{
    public partial class CreatedSpecificServices : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "projectSpaceId1",
                table: "Customers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "typeOfCustomer",
                table: "Customers",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Customers_projectSpaceId1",
                table: "Customers",
                column: "projectSpaceId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Customers_projectSpaces_projectSpaceId1",
                table: "Customers",
                column: "projectSpaceId1",
                principalTable: "projectSpaces",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Customers_projectSpaces_projectSpaceId1",
                table: "Customers");

            migrationBuilder.DropIndex(
                name: "IX_Customers_projectSpaceId1",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "projectSpaceId1",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "typeOfCustomer",
                table: "Customers");
        }
    }
}
