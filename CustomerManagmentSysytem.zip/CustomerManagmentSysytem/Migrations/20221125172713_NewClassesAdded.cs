﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CustomerManagmentSysytem.Migrations
{
    public partial class NewClassesAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "ServiceName",
                table: "ServiceTypes",
                nullable: false,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<int>(
                name: "projectSpaceId",
                table: "Customers",
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "token",
                table: "Customers",
                nullable: true);

            migrationBuilder.AddUniqueConstraint(
                name: "AK_ServiceTypes_ServiceName",
                table: "ServiceTypes",
                column: "ServiceName");

            migrationBuilder.CreateTable(
                name: "analytical",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FileName = table.Column<string>(nullable: true),
                    dateOfUpload = table.Column<DateTime>(nullable: false),
                    Images = table.Column<byte[]>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_analytical", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "projectSpaces",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Level = table.Column<int>(nullable: false),
                    Stage = table.Column<string>(nullable: true),
                    BackendType = table.Column<string>(nullable: false),
                    FrontendType = table.Column<string>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    CustomerID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_projectSpaces", x => x.Id);
                    table.ForeignKey(
                        name: "FK_projectSpaces_Customers_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Customers_projectSpaceId",
                table: "Customers",
                column: "projectSpaceId");

            migrationBuilder.CreateIndex(
                name: "IX_projectSpaces_CustomerID",
                table: "projectSpaces",
                column: "CustomerID");

            migrationBuilder.AddForeignKey(
                name: "FK_Customers_projectSpaces_projectSpaceId",
                table: "Customers",
                column: "projectSpaceId",
                principalTable: "projectSpaces",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Customers_projectSpaces_projectSpaceId",
                table: "Customers");

            migrationBuilder.DropTable(
                name: "analytical");

            migrationBuilder.DropTable(
                name: "projectSpaces");

            migrationBuilder.DropUniqueConstraint(
                name: "AK_ServiceTypes_ServiceName",
                table: "ServiceTypes");

            migrationBuilder.DropIndex(
                name: "IX_Customers_projectSpaceId",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "projectSpaceId",
                table: "Customers");

            migrationBuilder.DropColumn(
                name: "token",
                table: "Customers");

            migrationBuilder.AlterColumn<string>(
                name: "ServiceName",
                table: "ServiceTypes",
                nullable: false,
                oldClrType: typeof(string));
        }
    }
}
